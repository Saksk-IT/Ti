"""Quiz module service layer."""

