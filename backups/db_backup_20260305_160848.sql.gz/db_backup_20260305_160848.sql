--
-- PostgreSQL database dump
--

\restrict z1WtMlR6yYQw03tpudwwpaKX8EgZyTnNheMcOu3b2U4ejrcOeQRS83Y3S1VHpuL

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO studyuser;

--
-- Name: bank_share_records; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.bank_share_records (
    id integer NOT NULL,
    share_id integer NOT NULL,
    bank_id integer NOT NULL,
    user_id integer NOT NULL,
    status integer DEFAULT 1,
    last_access_at timestamp without time zone,
    access_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bank_share_records OWNER TO studyuser;

--
-- Name: bank_share_records_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.bank_share_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_share_records_id_seq OWNER TO studyuser;

--
-- Name: bank_share_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.bank_share_records_id_seq OWNED BY public.bank_share_records.id;


--
-- Name: bank_shares; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.bank_shares (
    id integer NOT NULL,
    bank_id integer NOT NULL,
    owner_id integer NOT NULL,
    share_code text,
    share_token text,
    permission text DEFAULT 'read'::text,
    expires_at timestamp without time zone,
    max_uses integer,
    current_uses integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bank_shares OWNER TO studyuser;

--
-- Name: bank_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.bank_shares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_shares_id_seq OWNER TO studyuser;

--
-- Name: bank_shares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.bank_shares_id_seq OWNED BY public.bank_shares.id;


--
-- Name: chat_conversations; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.chat_conversations (
    id integer NOT NULL,
    c_type text DEFAULT 'direct'::text NOT NULL,
    title text,
    direct_pair_key text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_conversations OWNER TO studyuser;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.chat_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_conversations_id_seq OWNER TO studyuser;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.chat_conversations_id_seq OWNED BY public.chat_conversations.id;


--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.chat_members (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'member'::text,
    last_read_message_id integer DEFAULT 0,
    joined_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_members OWNER TO studyuser;

--
-- Name: chat_members_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.chat_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_members_id_seq OWNER TO studyuser;

--
-- Name: chat_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.chat_members_id_seq OWNED BY public.chat_members.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    content text NOT NULL,
    content_type text DEFAULT 'text'::text,
    created_at timestamp without time zone DEFAULT now(),
    is_revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO studyuser;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO studyuser;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: code_drafts; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.code_drafts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    code text NOT NULL,
    language text DEFAULT 'python'::text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.code_drafts OWNER TO studyuser;

--
-- Name: code_drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.code_drafts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.code_drafts_id_seq OWNER TO studyuser;

--
-- Name: code_drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.code_drafts_id_seq OWNED BY public.code_drafts.id;


--
-- Name: code_submissions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.code_submissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    code text NOT NULL,
    language text NOT NULL,
    status text NOT NULL,
    passed_cases integer DEFAULT 0,
    total_cases integer DEFAULT 0,
    execution_time double precision,
    error_message text,
    score double precision DEFAULT 0.0,
    submitted_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.code_submissions OWNER TO studyuser;

--
-- Name: code_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.code_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.code_submissions_id_seq OWNER TO studyuser;

--
-- Name: code_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.code_submissions_id_seq OWNED BY public.code_submissions.id;


--
-- Name: coding_questions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.coding_questions (
    id integer NOT NULL,
    coding_subject_id integer NOT NULL,
    title text NOT NULL,
    q_type text NOT NULL,
    description text NOT NULL,
    difficulty text NOT NULL,
    code_template text,
    programming_language text DEFAULT 'python'::text,
    time_limit integer DEFAULT 5,
    memory_limit integer DEFAULT 128,
    test_cases_json text NOT NULL,
    examples text,
    constraints text,
    hints text,
    is_enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.coding_questions OWNER TO studyuser;

--
-- Name: coding_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.coding_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coding_questions_id_seq OWNER TO studyuser;

--
-- Name: coding_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.coding_questions_id_seq OWNED BY public.coding_questions.id;


--
-- Name: coding_statistics; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.coding_statistics (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    total_submissions integer DEFAULT 0,
    accepted_submissions integer DEFAULT 0,
    best_time double precision,
    best_score double precision DEFAULT 0.0,
    first_accepted_at timestamp without time zone,
    last_submitted_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.coding_statistics OWNER TO studyuser;

--
-- Name: coding_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.coding_statistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coding_statistics_id_seq OWNER TO studyuser;

--
-- Name: coding_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.coding_statistics_id_seq OWNED BY public.coding_statistics.id;


--
-- Name: coding_subjects; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.coding_subjects (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    is_locked boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.coding_subjects OWNER TO studyuser;

--
-- Name: coding_subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.coding_subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coding_subjects_id_seq OWNER TO studyuser;

--
-- Name: coding_subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.coding_subjects_id_seq OWNED BY public.coding_subjects.id;


--
-- Name: duplicate_check_records; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.duplicate_check_records (
    id integer NOT NULL,
    subject_id integer NOT NULL,
    total_pairs integer DEFAULT 0,
    duplicates_json text NOT NULL,
    similarity_threshold double precision DEFAULT 0.8,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.duplicate_check_records OWNER TO studyuser;

--
-- Name: duplicate_check_records_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.duplicate_check_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.duplicate_check_records_id_seq OWNER TO studyuser;

--
-- Name: duplicate_check_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.duplicate_check_records_id_seq OWNED BY public.duplicate_check_records.id;


--
-- Name: email_verification_codes; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.email_verification_codes (
    id integer NOT NULL,
    email text NOT NULL,
    code text NOT NULL,
    code_type text NOT NULL,
    user_id integer,
    is_used boolean DEFAULT false,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    used_at timestamp without time zone
);


ALTER TABLE public.email_verification_codes OWNER TO studyuser;

--
-- Name: email_verification_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.email_verification_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_verification_codes_id_seq OWNER TO studyuser;

--
-- Name: email_verification_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.email_verification_codes_id_seq OWNED BY public.email_verification_codes.id;


--
-- Name: exam_questions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.exam_questions (
    id integer NOT NULL,
    exam_id integer NOT NULL,
    question_id integer NOT NULL,
    order_index integer NOT NULL,
    score_val double precision DEFAULT 1,
    user_answer text,
    is_correct boolean,
    answered_at timestamp without time zone
);


ALTER TABLE public.exam_questions OWNER TO studyuser;

--
-- Name: exam_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.exam_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exam_questions_id_seq OWNER TO studyuser;

--
-- Name: exam_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.exam_questions_id_seq OWNED BY public.exam_questions.id;


--
-- Name: exam_templates; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.exam_templates (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    config_json text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.exam_templates OWNER TO studyuser;

--
-- Name: exam_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.exam_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exam_templates_id_seq OWNER TO studyuser;

--
-- Name: exam_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.exam_templates_id_seq OWNED BY public.exam_templates.id;


--
-- Name: exams; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.exams (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject text,
    duration_minutes integer NOT NULL,
    config_json text,
    total_score double precision DEFAULT 0,
    status text DEFAULT 'ongoing'::text,
    started_at timestamp without time zone DEFAULT now(),
    submitted_at timestamp without time zone
);


ALTER TABLE public.exams OWNER TO studyuser;

--
-- Name: exams_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.exams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exams_id_seq OWNER TO studyuser;

--
-- Name: exams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.exams_id_seq OWNED BY public.exams.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.favorites OWNER TO studyuser;

--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorites_id_seq OWNER TO studyuser;

--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: forum_boards; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_boards (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text DEFAULT ''::text,
    board_type character varying(20) DEFAULT 'custom'::character varying NOT NULL,
    subject_id integer,
    icon character varying(50) DEFAULT ''::character varying,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_boards OWNER TO studyuser;

--
-- Name: forum_boards_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_boards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_boards_id_seq OWNER TO studyuser;

--
-- Name: forum_boards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_boards_id_seq OWNED BY public.forum_boards.id;


--
-- Name: forum_comments; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    author_id integer NOT NULL,
    parent_id integer,
    reply_to_user_id integer,
    content text NOT NULL,
    is_deleted boolean DEFAULT false,
    deleted_by integer,
    deleted_at timestamp without time zone,
    like_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_comments OWNER TO studyuser;

--
-- Name: forum_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_comments_id_seq OWNER TO studyuser;

--
-- Name: forum_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_comments_id_seq OWNED BY public.forum_comments.id;


--
-- Name: forum_favorites; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_favorites OWNER TO studyuser;

--
-- Name: forum_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_favorites_id_seq OWNER TO studyuser;

--
-- Name: forum_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_favorites_id_seq OWNED BY public.forum_favorites.id;


--
-- Name: forum_likes; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_likes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_type character varying(10) NOT NULL,
    target_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_likes OWNER TO studyuser;

--
-- Name: forum_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_likes_id_seq OWNER TO studyuser;

--
-- Name: forum_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_likes_id_seq OWNED BY public.forum_likes.id;


--
-- Name: forum_mentions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_mentions (
    id integer NOT NULL,
    source_type character varying(10) NOT NULL,
    source_id integer NOT NULL,
    mentioned_user_id integer NOT NULL,
    mentioner_id integer NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_mentions OWNER TO studyuser;

--
-- Name: forum_mentions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_mentions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_mentions_id_seq OWNER TO studyuser;

--
-- Name: forum_mentions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_mentions_id_seq OWNED BY public.forum_mentions.id;


--
-- Name: forum_poll_votes; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_poll_votes (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    option_index integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_poll_votes OWNER TO studyuser;

--
-- Name: forum_poll_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_poll_votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_poll_votes_id_seq OWNER TO studyuser;

--
-- Name: forum_poll_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_poll_votes_id_seq OWNED BY public.forum_poll_votes.id;


--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_posts (
    id integer NOT NULL,
    board_id integer NOT NULL,
    author_id integer NOT NULL,
    title character varying(200) NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    content_format character varying(10) DEFAULT 'html'::character varying,
    images json,
    question_refs json,
    is_pinned boolean DEFAULT false,
    is_featured boolean DEFAULT false,
    is_locked boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    deleted_by integer,
    deleted_at timestamp without time zone,
    comment_count integer DEFAULT 0,
    like_count integer DEFAULT 0,
    favorite_count integer DEFAULT 0,
    view_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_comment_at timestamp without time zone,
    poll json,
    search_vector tsvector GENERATED ALWAYS AS ((setweight(to_tsvector('simple'::regconfig, (COALESCE(title, ''::character varying))::text), 'A'::"char") || setweight(to_tsvector('simple'::regconfig, COALESCE(content, ''::text)), 'B'::"char"))) STORED,
    cover_image text,
    tags json DEFAULT '[]'::jsonb,
    summary text,
    markdown_source text,
    is_hidden boolean DEFAULT false NOT NULL
);


ALTER TABLE public.forum_posts OWNER TO studyuser;

--
-- Name: forum_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_posts_id_seq OWNER TO studyuser;

--
-- Name: forum_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_posts_id_seq OWNED BY public.forum_posts.id;


--
-- Name: forum_reactions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_reactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_type character varying(10) NOT NULL,
    target_id integer NOT NULL,
    emoji character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_reactions OWNER TO studyuser;

--
-- Name: forum_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_reactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_reactions_id_seq OWNER TO studyuser;

--
-- Name: forum_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_reactions_id_seq OWNED BY public.forum_reactions.id;


--
-- Name: forum_reports; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_reports (
    id integer NOT NULL,
    reporter_id integer NOT NULL,
    target_type character varying(10) NOT NULL,
    target_id integer NOT NULL,
    reason character varying(50) NOT NULL,
    detail text DEFAULT ''::text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    handled_by integer,
    handled_at timestamp without time zone,
    handle_note text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_reports OWNER TO studyuser;

--
-- Name: forum_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_reports_id_seq OWNER TO studyuser;

--
-- Name: forum_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_reports_id_seq OWNED BY public.forum_reports.id;


--
-- Name: forum_user_bans; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.forum_user_bans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    banned_by integer,
    reason text DEFAULT ''::text NOT NULL,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_user_bans OWNER TO studyuser;

--
-- Name: forum_user_bans_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.forum_user_bans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forum_user_bans_id_seq OWNER TO studyuser;

--
-- Name: forum_user_bans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.forum_user_bans_id_seq OWNED BY public.forum_user_bans.id;


--
-- Name: interaction_notifications; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.interaction_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    actor_id integer NOT NULL,
    action_type character varying(20) NOT NULL,
    target_type character varying(20),
    target_id integer,
    post_id integer,
    content_preview character varying(200) DEFAULT ''::character varying,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.interaction_notifications OWNER TO studyuser;

--
-- Name: interaction_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.interaction_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interaction_notifications_id_seq OWNER TO studyuser;

--
-- Name: interaction_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.interaction_notifications_id_seq OWNED BY public.interaction_notifications.id;


--
-- Name: mistakes; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.mistakes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    wrong_count integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_updated timestamp without time zone DEFAULT now()
);


ALTER TABLE public.mistakes OWNER TO studyuser;

--
-- Name: mistakes_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.mistakes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mistakes_id_seq OWNER TO studyuser;

--
-- Name: mistakes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.mistakes_id_seq OWNED BY public.mistakes.id;


--
-- Name: notification_dismissals; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.notification_dismissals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notification_id integer NOT NULL,
    dismissed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_dismissals OWNER TO studyuser;

--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.notification_dismissals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_dismissals_id_seq OWNER TO studyuser;

--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.notification_dismissals_id_seq OWNED BY public.notification_dismissals.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    n_type text DEFAULT 'info'::text NOT NULL,
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    start_at timestamp without time zone,
    end_at timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO studyuser;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO studyuser;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: popup_dismissals; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.popup_dismissals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    popup_id integer NOT NULL,
    dismissed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.popup_dismissals OWNER TO studyuser;

--
-- Name: popup_dismissals_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.popup_dismissals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.popup_dismissals_id_seq OWNER TO studyuser;

--
-- Name: popup_dismissals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.popup_dismissals_id_seq OWNED BY public.popup_dismissals.id;


--
-- Name: popup_views; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.popup_views (
    id integer NOT NULL,
    popup_id integer NOT NULL,
    user_id integer,
    viewed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.popup_views OWNER TO studyuser;

--
-- Name: popup_views_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.popup_views_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.popup_views_id_seq OWNER TO studyuser;

--
-- Name: popup_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.popup_views_id_seq OWNED BY public.popup_views.id;


--
-- Name: popups; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.popups (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    popup_type text DEFAULT 'info'::text NOT NULL,
    is_active boolean DEFAULT true,
    priority integer DEFAULT 0,
    start_at timestamp without time zone,
    end_at timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT ck_popups_popup_type CHECK ((popup_type = ANY (ARRAY['info'::text, 'warning'::text, 'success'::text, 'error'::text])))
);


ALTER TABLE public.popups OWNER TO studyuser;

--
-- Name: popups_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.popups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.popups_id_seq OWNER TO studyuser;

--
-- Name: popups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.popups_id_seq OWNED BY public.popups.id;


--
-- Name: public_bank_users; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.public_bank_users (
    id integer NOT NULL,
    bank_id integer NOT NULL,
    user_id integer NOT NULL,
    last_access_at timestamp without time zone,
    access_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.public_bank_users OWNER TO studyuser;

--
-- Name: public_bank_users_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.public_bank_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.public_bank_users_id_seq OWNER TO studyuser;

--
-- Name: public_bank_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.public_bank_users_id_seq OWNED BY public.public_bank_users.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.questions (
    id integer NOT NULL,
    subject_id integer,
    type text NOT NULL,
    content text NOT NULL,
    options text DEFAULT '[]'::text,
    answer text DEFAULT '[]'::text,
    analysis text,
    tags text DEFAULT '[]'::text,
    difficulty integer DEFAULT 1,
    image_path text,
    source text,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.questions OWNER TO studyuser;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.questions_id_seq OWNER TO studyuser;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: reinforce_similar_cache; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.reinforce_similar_cache (
    id integer NOT NULL,
    source text NOT NULL,
    scope_id integer NOT NULL,
    version text NOT NULL,
    pairs_json text NOT NULL,
    pairs_count integer DEFAULT 0,
    computed_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reinforce_similar_cache OWNER TO studyuser;

--
-- Name: reinforce_similar_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.reinforce_similar_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reinforce_similar_cache_id_seq OWNER TO studyuser;

--
-- Name: reinforce_similar_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.reinforce_similar_cache_id_seq OWNED BY public.reinforce_similar_cache.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.schema_migrations (
    id text NOT NULL,
    applied_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.schema_migrations OWNER TO studyuser;

--
-- Name: study_learning; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.study_learning (
    id integer NOT NULL,
    user_id integer NOT NULL,
    source text NOT NULL,
    scope_id integer NOT NULL,
    question_id integer NOT NULL,
    streak integer DEFAULT 0,
    is_learned boolean DEFAULT false,
    correct_count integer DEFAULT 0,
    wrong_count integer DEFAULT 0,
    last_result text,
    last_answered_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.study_learning OWNER TO studyuser;

--
-- Name: study_learning_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.study_learning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.study_learning_id_seq OWNER TO studyuser;

--
-- Name: study_learning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.study_learning_id_seq OWNED BY public.study_learning.id;


--
-- Name: study_review; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.study_review (
    id integer NOT NULL,
    user_id integer NOT NULL,
    source text NOT NULL,
    scope_id integer NOT NULL,
    question_id integer NOT NULL,
    review_level integer DEFAULT 0,
    next_due_at timestamp without time zone,
    last_review_at timestamp without time zone,
    last_rating text,
    lapse_count integer DEFAULT 0,
    is_mastered boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.study_review OWNER TO studyuser;

--
-- Name: study_review_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.study_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.study_review_id_seq OWNER TO studyuser;

--
-- Name: study_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.study_review_id_seq OWNED BY public.study_review.id;


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    is_locked boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.subjects OWNER TO studyuser;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO studyuser;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: system_config; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.system_config (
    id integer NOT NULL,
    config_key text NOT NULL,
    config_value text NOT NULL,
    description text,
    updated_at timestamp without time zone DEFAULT now(),
    updated_by integer
);


ALTER TABLE public.system_config OWNER TO studyuser;

--
-- Name: system_config_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.system_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_config_id_seq OWNER TO studyuser;

--
-- Name: system_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.system_config_id_seq OWNED BY public.system_config.id;


--
-- Name: user_answers; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_answers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    question_id integer NOT NULL,
    user_answer text,
    is_correct boolean,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_answers OWNER TO studyuser;

--
-- Name: user_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_answers_id_seq OWNER TO studyuser;

--
-- Name: user_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_answers_id_seq OWNED BY public.user_answers.id;


--
-- Name: user_bank_answers; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_bank_answers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    bank_id integer NOT NULL,
    question_id integer NOT NULL,
    user_answer text,
    is_correct boolean,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_bank_answers OWNER TO studyuser;

--
-- Name: user_bank_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_bank_answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_bank_answers_id_seq OWNER TO studyuser;

--
-- Name: user_bank_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_bank_answers_id_seq OWNED BY public.user_bank_answers.id;


--
-- Name: user_bank_categories; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_bank_categories (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    description text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_bank_categories OWNER TO studyuser;

--
-- Name: user_bank_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_bank_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_bank_categories_id_seq OWNER TO studyuser;

--
-- Name: user_bank_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_bank_categories_id_seq OWNED BY public.user_bank_categories.id;


--
-- Name: user_bank_favorites; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_bank_favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    bank_id integer NOT NULL,
    question_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_bank_favorites OWNER TO studyuser;

--
-- Name: user_bank_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_bank_favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_bank_favorites_id_seq OWNER TO studyuser;

--
-- Name: user_bank_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_bank_favorites_id_seq OWNED BY public.user_bank_favorites.id;


--
-- Name: user_bank_mistakes; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_bank_mistakes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    bank_id integer NOT NULL,
    question_id integer NOT NULL,
    wrong_count integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_bank_mistakes OWNER TO studyuser;

--
-- Name: user_bank_mistakes_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_bank_mistakes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_bank_mistakes_id_seq OWNER TO studyuser;

--
-- Name: user_bank_mistakes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_bank_mistakes_id_seq OWNED BY public.user_bank_mistakes.id;


--
-- Name: user_bank_questions; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_bank_questions (
    id integer NOT NULL,
    bank_id integer NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    content text NOT NULL,
    options text DEFAULT '[]'::text,
    answer text DEFAULT '[]'::text,
    analysis text,
    tags text DEFAULT '[]'::text,
    difficulty integer DEFAULT 1,
    image_path text,
    source_type text DEFAULT 'custom'::text,
    source_question_id integer,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_bank_questions OWNER TO studyuser;

--
-- Name: user_bank_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_bank_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_bank_questions_id_seq OWNER TO studyuser;

--
-- Name: user_bank_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_bank_questions_id_seq OWNED BY public.user_bank_questions.id;


--
-- Name: user_checkins; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_checkins (
    id integer NOT NULL,
    user_id integer NOT NULL,
    checkin_date text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_checkins OWNER TO studyuser;

--
-- Name: user_checkins_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_checkins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_checkins_id_seq OWNER TO studyuser;

--
-- Name: user_checkins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_checkins_id_seq OWNED BY public.user_checkins.id;


--
-- Name: user_coding_stats; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_coding_stats (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total_submissions integer DEFAULT 0,
    accepted_submissions integer DEFAULT 0,
    solved_questions integer DEFAULT 0,
    total_score double precision DEFAULT 0.0,
    average_score double precision DEFAULT 0.0,
    acceptance_rate double precision DEFAULT 0.0,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_coding_stats OWNER TO studyuser;

--
-- Name: user_coding_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_coding_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_coding_stats_id_seq OWNER TO studyuser;

--
-- Name: user_coding_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_coding_stats_id_seq OWNED BY public.user_coding_stats.id;


--
-- Name: user_follows; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_follows (
    id integer NOT NULL,
    follower_id integer NOT NULL,
    following_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT ck_user_follows_no_self CHECK ((follower_id <> following_id))
);


ALTER TABLE public.user_follows OWNER TO studyuser;

--
-- Name: user_follows_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_follows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_follows_id_seq OWNER TO studyuser;

--
-- Name: user_follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_follows_id_seq OWNED BY public.user_follows.id;


--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_progress (
    id integer NOT NULL,
    user_id integer NOT NULL,
    p_key text NOT NULL,
    data text NOT NULL,
    updated_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_progress OWNER TO studyuser;

--
-- Name: user_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_progress_id_seq OWNER TO studyuser;

--
-- Name: user_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_progress_id_seq OWNED BY public.user_progress.id;


--
-- Name: user_question_banks; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_question_banks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category_id integer,
    name text NOT NULL,
    description text,
    cover_image text,
    is_public boolean DEFAULT false,
    public_description text,
    allow_copy boolean DEFAULT true,
    public_at timestamp without time zone,
    question_count integer DEFAULT 0,
    share_count integer DEFAULT 0,
    public_use_count integer DEFAULT 0,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_question_banks OWNER TO studyuser;

--
-- Name: user_question_banks_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_question_banks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_question_banks_id_seq OWNER TO studyuser;

--
-- Name: user_question_banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_question_banks_id_seq OWNED BY public.user_question_banks.id;


--
-- Name: user_question_tag_items; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_question_tag_items (
    user_id integer NOT NULL,
    scope text NOT NULL,
    scope_id integer DEFAULT 0 NOT NULL,
    question_id integer NOT NULL,
    tag text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_question_tag_items OWNER TO studyuser;

--
-- Name: user_quiz_stats; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_quiz_stats (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total_answered integer DEFAULT 0,
    last_reset_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_quiz_stats OWNER TO studyuser;

--
-- Name: user_quiz_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_quiz_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_quiz_stats_id_seq OWNER TO studyuser;

--
-- Name: user_quiz_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_quiz_stats_id_seq OWNED BY public.user_quiz_stats.id;


--
-- Name: user_remarks; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_remarks (
    id integer NOT NULL,
    owner_user_id integer NOT NULL,
    target_user_id integer NOT NULL,
    remark text NOT NULL,
    updated_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_remarks OWNER TO studyuser;

--
-- Name: user_remarks_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_remarks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_remarks_id_seq OWNER TO studyuser;

--
-- Name: user_remarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_remarks_id_seq OWNED BY public.user_remarks.id;


--
-- Name: user_subjects; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.user_subjects (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject_id integer NOT NULL,
    restricted_at timestamp without time zone DEFAULT now(),
    restricted_by integer
);


ALTER TABLE public.user_subjects OWNER TO studyuser;

--
-- Name: user_subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.user_subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_subjects_id_seq OWNER TO studyuser;

--
-- Name: user_subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.user_subjects_id_seq OWNED BY public.user_subjects.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: studyuser
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying NOT NULL,
    password_hash text NOT NULL,
    is_admin boolean DEFAULT false,
    is_locked boolean DEFAULT false,
    session_version integer DEFAULT 0,
    avatar text,
    contact text,
    college text,
    last_active timestamp without time zone,
    is_subject_admin boolean DEFAULT false,
    is_notification_admin boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    email text,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp without time zone,
    has_password_set boolean DEFAULT false,
    openid text,
    phone character varying(20),
    phone_verified boolean DEFAULT false,
    phone_verified_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO studyuser;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: studyuser
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO studyuser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: studyuser
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bank_share_records id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records ALTER COLUMN id SET DEFAULT nextval('public.bank_share_records_id_seq'::regclass);


--
-- Name: bank_shares id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares ALTER COLUMN id SET DEFAULT nextval('public.bank_shares_id_seq'::regclass);


--
-- Name: chat_conversations id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_conversations ALTER COLUMN id SET DEFAULT nextval('public.chat_conversations_id_seq'::regclass);


--
-- Name: chat_members id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_members ALTER COLUMN id SET DEFAULT nextval('public.chat_members_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: code_drafts id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_drafts ALTER COLUMN id SET DEFAULT nextval('public.code_drafts_id_seq'::regclass);


--
-- Name: code_submissions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_submissions ALTER COLUMN id SET DEFAULT nextval('public.code_submissions_id_seq'::regclass);


--
-- Name: coding_questions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_questions ALTER COLUMN id SET DEFAULT nextval('public.coding_questions_id_seq'::regclass);


--
-- Name: coding_statistics id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_statistics ALTER COLUMN id SET DEFAULT nextval('public.coding_statistics_id_seq'::regclass);


--
-- Name: coding_subjects id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_subjects ALTER COLUMN id SET DEFAULT nextval('public.coding_subjects_id_seq'::regclass);


--
-- Name: duplicate_check_records id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.duplicate_check_records ALTER COLUMN id SET DEFAULT nextval('public.duplicate_check_records_id_seq'::regclass);


--
-- Name: email_verification_codes id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.email_verification_codes ALTER COLUMN id SET DEFAULT nextval('public.email_verification_codes_id_seq'::regclass);


--
-- Name: exam_questions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_questions ALTER COLUMN id SET DEFAULT nextval('public.exam_questions_id_seq'::regclass);


--
-- Name: exam_templates id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_templates ALTER COLUMN id SET DEFAULT nextval('public.exam_templates_id_seq'::regclass);


--
-- Name: exams id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exams ALTER COLUMN id SET DEFAULT nextval('public.exams_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: forum_boards id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_boards ALTER COLUMN id SET DEFAULT nextval('public.forum_boards_id_seq'::regclass);


--
-- Name: forum_comments id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments ALTER COLUMN id SET DEFAULT nextval('public.forum_comments_id_seq'::regclass);


--
-- Name: forum_favorites id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_favorites ALTER COLUMN id SET DEFAULT nextval('public.forum_favorites_id_seq'::regclass);


--
-- Name: forum_likes id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_likes ALTER COLUMN id SET DEFAULT nextval('public.forum_likes_id_seq'::regclass);


--
-- Name: forum_mentions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_mentions ALTER COLUMN id SET DEFAULT nextval('public.forum_mentions_id_seq'::regclass);


--
-- Name: forum_poll_votes id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_poll_votes ALTER COLUMN id SET DEFAULT nextval('public.forum_poll_votes_id_seq'::regclass);


--
-- Name: forum_posts id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_posts ALTER COLUMN id SET DEFAULT nextval('public.forum_posts_id_seq'::regclass);


--
-- Name: forum_reactions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reactions ALTER COLUMN id SET DEFAULT nextval('public.forum_reactions_id_seq'::regclass);


--
-- Name: forum_reports id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reports ALTER COLUMN id SET DEFAULT nextval('public.forum_reports_id_seq'::regclass);


--
-- Name: forum_user_bans id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_user_bans ALTER COLUMN id SET DEFAULT nextval('public.forum_user_bans_id_seq'::regclass);


--
-- Name: interaction_notifications id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.interaction_notifications ALTER COLUMN id SET DEFAULT nextval('public.interaction_notifications_id_seq'::regclass);


--
-- Name: mistakes id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.mistakes ALTER COLUMN id SET DEFAULT nextval('public.mistakes_id_seq'::regclass);


--
-- Name: notification_dismissals id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notification_dismissals ALTER COLUMN id SET DEFAULT nextval('public.notification_dismissals_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: popup_dismissals id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_dismissals ALTER COLUMN id SET DEFAULT nextval('public.popup_dismissals_id_seq'::regclass);


--
-- Name: popup_views id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_views ALTER COLUMN id SET DEFAULT nextval('public.popup_views_id_seq'::regclass);


--
-- Name: popups id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popups ALTER COLUMN id SET DEFAULT nextval('public.popups_id_seq'::regclass);


--
-- Name: public_bank_users id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.public_bank_users ALTER COLUMN id SET DEFAULT nextval('public.public_bank_users_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: reinforce_similar_cache id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.reinforce_similar_cache ALTER COLUMN id SET DEFAULT nextval('public.reinforce_similar_cache_id_seq'::regclass);


--
-- Name: study_learning id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_learning ALTER COLUMN id SET DEFAULT nextval('public.study_learning_id_seq'::regclass);


--
-- Name: study_review id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_review ALTER COLUMN id SET DEFAULT nextval('public.study_review_id_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Name: system_config id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.system_config ALTER COLUMN id SET DEFAULT nextval('public.system_config_id_seq'::regclass);


--
-- Name: user_answers id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_answers ALTER COLUMN id SET DEFAULT nextval('public.user_answers_id_seq'::regclass);


--
-- Name: user_bank_answers id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers ALTER COLUMN id SET DEFAULT nextval('public.user_bank_answers_id_seq'::regclass);


--
-- Name: user_bank_categories id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_categories ALTER COLUMN id SET DEFAULT nextval('public.user_bank_categories_id_seq'::regclass);


--
-- Name: user_bank_favorites id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites ALTER COLUMN id SET DEFAULT nextval('public.user_bank_favorites_id_seq'::regclass);


--
-- Name: user_bank_mistakes id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes ALTER COLUMN id SET DEFAULT nextval('public.user_bank_mistakes_id_seq'::regclass);


--
-- Name: user_bank_questions id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_questions ALTER COLUMN id SET DEFAULT nextval('public.user_bank_questions_id_seq'::regclass);


--
-- Name: user_checkins id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_checkins ALTER COLUMN id SET DEFAULT nextval('public.user_checkins_id_seq'::regclass);


--
-- Name: user_coding_stats id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_coding_stats ALTER COLUMN id SET DEFAULT nextval('public.user_coding_stats_id_seq'::regclass);


--
-- Name: user_follows id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_follows ALTER COLUMN id SET DEFAULT nextval('public.user_follows_id_seq'::regclass);


--
-- Name: user_progress id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_progress ALTER COLUMN id SET DEFAULT nextval('public.user_progress_id_seq'::regclass);


--
-- Name: user_question_banks id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_banks ALTER COLUMN id SET DEFAULT nextval('public.user_question_banks_id_seq'::regclass);


--
-- Name: user_quiz_stats id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_quiz_stats ALTER COLUMN id SET DEFAULT nextval('public.user_quiz_stats_id_seq'::regclass);


--
-- Name: user_remarks id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_remarks ALTER COLUMN id SET DEFAULT nextval('public.user_remarks_id_seq'::regclass);


--
-- Name: user_subjects id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects ALTER COLUMN id SET DEFAULT nextval('public.user_subjects_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.alembic_version (version_num) FROM stdin;
c3d4e5f6a7b8
\.


--
-- Data for Name: bank_share_records; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.bank_share_records (id, share_id, bank_id, user_id, status, last_access_at, access_count, created_at) FROM stdin;
\.


--
-- Data for Name: bank_shares; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.bank_shares (id, bank_id, owner_id, share_code, share_token, permission, expires_at, max_uses, current_uses, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: chat_conversations; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.chat_conversations (id, c_type, title, direct_pair_key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.chat_members (id, conversation_id, user_id, role, last_read_message_id, joined_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.chat_messages (id, conversation_id, sender_id, content, content_type, created_at, is_revoked) FROM stdin;
\.


--
-- Data for Name: code_drafts; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.code_drafts (id, user_id, question_id, code, language, updated_at) FROM stdin;
\.


--
-- Data for Name: code_submissions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.code_submissions (id, user_id, question_id, code, language, status, passed_cases, total_cases, execution_time, error_message, score, submitted_at) FROM stdin;
\.


--
-- Data for Name: coding_questions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.coding_questions (id, coding_subject_id, title, q_type, description, difficulty, code_template, programming_language, time_limit, memory_limit, test_cases_json, examples, constraints, hints, is_enabled, created_at) FROM stdin;
\.


--
-- Data for Name: coding_statistics; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.coding_statistics (id, user_id, question_id, total_submissions, accepted_submissions, best_time, best_score, first_accepted_at, last_submitted_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coding_subjects; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.coding_subjects (id, name, description, is_locked, created_at) FROM stdin;
\.


--
-- Data for Name: duplicate_check_records; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.duplicate_check_records (id, subject_id, total_pairs, duplicates_json, similarity_threshold, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: email_verification_codes; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.email_verification_codes (id, email, code, code_type, user_id, is_used, expires_at, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: exam_questions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.exam_questions (id, exam_id, question_id, order_index, score_val, user_answer, is_correct, answered_at) FROM stdin;
\.


--
-- Data for Name: exam_templates; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.exam_templates (id, user_id, title, config_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.exams (id, user_id, subject, duration_minutes, config_json, total_score, status, started_at, submitted_at) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.favorites (id, user_id, question_id, created_at) FROM stdin;
\.


--
-- Data for Name: forum_boards; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_boards (id, name, slug, description, board_type, subject_id, icon, sort_order, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_comments; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_comments (id, post_id, author_id, parent_id, reply_to_user_id, content, is_deleted, deleted_by, deleted_at, like_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_favorites; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_favorites (id, user_id, post_id, created_at) FROM stdin;
\.


--
-- Data for Name: forum_likes; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_likes (id, user_id, target_type, target_id, created_at) FROM stdin;
\.


--
-- Data for Name: forum_mentions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_mentions (id, source_type, source_id, mentioned_user_id, mentioner_id, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: forum_poll_votes; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_poll_votes (id, post_id, user_id, option_index, created_at) FROM stdin;
\.


--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_posts (id, board_id, author_id, title, content, content_format, images, question_refs, is_pinned, is_featured, is_locked, is_deleted, deleted_by, deleted_at, comment_count, like_count, favorite_count, view_count, created_at, updated_at, last_comment_at, poll, cover_image, tags, summary, markdown_source, is_hidden) FROM stdin;
\.


--
-- Data for Name: forum_reactions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_reactions (id, user_id, target_type, target_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: forum_reports; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_reports (id, reporter_id, target_type, target_id, reason, detail, status, handled_by, handled_at, handle_note, created_at) FROM stdin;
\.


--
-- Data for Name: forum_user_bans; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.forum_user_bans (id, user_id, banned_by, reason, expires_at, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: interaction_notifications; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.interaction_notifications (id, user_id, actor_id, action_type, target_type, target_id, post_id, content_preview, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: mistakes; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.mistakes (id, user_id, question_id, wrong_count, created_at, updated_at, last_updated) FROM stdin;
\.


--
-- Data for Name: notification_dismissals; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.notification_dismissals (id, user_id, notification_id, dismissed_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.notifications (id, title, content, n_type, priority, is_active, start_at, end_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: popup_dismissals; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.popup_dismissals (id, user_id, popup_id, dismissed_at) FROM stdin;
\.


--
-- Data for Name: popup_views; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.popup_views (id, popup_id, user_id, viewed_at) FROM stdin;
\.


--
-- Data for Name: popups; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.popups (id, title, content, popup_type, is_active, priority, start_at, end_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: public_bank_users; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.public_bank_users (id, bank_id, user_id, last_access_at, access_count, created_at) FROM stdin;
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.questions (id, subject_id, type, content, options, answer, analysis, tags, difficulty, image_path, source, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reinforce_similar_cache; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.reinforce_similar_cache (id, source, scope_id, version, pairs_json, pairs_count, computed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.schema_migrations (id, applied_at) FROM stdin;
\.


--
-- Data for Name: study_learning; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.study_learning (id, user_id, source, scope_id, question_id, streak, is_learned, correct_count, wrong_count, last_result, last_answered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: study_review; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.study_review (id, user_id, source, scope_id, question_id, review_level, next_due_at, last_review_at, last_rating, lapse_count, is_mastered, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.subjects (id, name, description, is_locked, created_at) FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.system_config (id, config_key, config_value, description, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: user_answers; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_answers (id, user_id, question_id, user_answer, is_correct, created_at) FROM stdin;
\.


--
-- Data for Name: user_bank_answers; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_bank_answers (id, user_id, bank_id, question_id, user_answer, is_correct, created_at) FROM stdin;
\.


--
-- Data for Name: user_bank_categories; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_bank_categories (id, user_id, name, description, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_bank_favorites; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_bank_favorites (id, user_id, bank_id, question_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_bank_mistakes; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_bank_mistakes (id, user_id, bank_id, question_id, wrong_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_bank_questions; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_bank_questions (id, bank_id, user_id, type, content, options, answer, analysis, tags, difficulty, image_path, source_type, source_question_id, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_checkins; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_checkins (id, user_id, checkin_date, created_at) FROM stdin;
\.


--
-- Data for Name: user_coding_stats; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_coding_stats (id, user_id, total_submissions, accepted_submissions, solved_questions, total_score, average_score, acceptance_rate, updated_at) FROM stdin;
\.


--
-- Data for Name: user_follows; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_follows (id, follower_id, following_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_progress (id, user_id, p_key, data, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_question_banks; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_question_banks (id, user_id, category_id, name, description, cover_image, is_public, public_description, allow_copy, public_at, question_count, share_count, public_use_count, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_question_tag_items; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_question_tag_items (user_id, scope, scope_id, question_id, tag, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_quiz_stats; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_quiz_stats (id, user_id, total_answered, last_reset_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_remarks; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_remarks (id, owner_user_id, target_user_id, remark, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_subjects; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.user_subjects (id, user_id, subject_id, restricted_at, restricted_by) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: studyuser
--

COPY public.users (id, username, password_hash, is_admin, is_locked, session_version, avatar, contact, college, last_active, is_subject_admin, is_notification_admin, created_at, email, email_verified, email_verified_at, has_password_set, openid, phone, phone_verified, phone_verified_at) FROM stdin;
\.


--
-- Name: bank_share_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.bank_share_records_id_seq', 1, false);


--
-- Name: bank_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.bank_shares_id_seq', 1, false);


--
-- Name: chat_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.chat_conversations_id_seq', 1, false);


--
-- Name: chat_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.chat_members_id_seq', 1, false);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 1, false);


--
-- Name: code_drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.code_drafts_id_seq', 1, false);


--
-- Name: code_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.code_submissions_id_seq', 1, false);


--
-- Name: coding_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.coding_questions_id_seq', 1, false);


--
-- Name: coding_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.coding_statistics_id_seq', 1, false);


--
-- Name: coding_subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.coding_subjects_id_seq', 1, false);


--
-- Name: duplicate_check_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.duplicate_check_records_id_seq', 1, false);


--
-- Name: email_verification_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.email_verification_codes_id_seq', 1, false);


--
-- Name: exam_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.exam_questions_id_seq', 1, false);


--
-- Name: exam_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.exam_templates_id_seq', 1, false);


--
-- Name: exams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.exams_id_seq', 1, false);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, false);


--
-- Name: forum_boards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_boards_id_seq', 1, false);


--
-- Name: forum_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_comments_id_seq', 1, false);


--
-- Name: forum_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_favorites_id_seq', 1, false);


--
-- Name: forum_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_likes_id_seq', 1, false);


--
-- Name: forum_mentions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_mentions_id_seq', 1, false);


--
-- Name: forum_poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_poll_votes_id_seq', 1, false);


--
-- Name: forum_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_posts_id_seq', 1, false);


--
-- Name: forum_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_reactions_id_seq', 1, false);


--
-- Name: forum_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_reports_id_seq', 1, false);


--
-- Name: forum_user_bans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.forum_user_bans_id_seq', 1, false);


--
-- Name: interaction_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.interaction_notifications_id_seq', 1, false);


--
-- Name: mistakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.mistakes_id_seq', 1, false);


--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.notification_dismissals_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: popup_dismissals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.popup_dismissals_id_seq', 1, false);


--
-- Name: popup_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.popup_views_id_seq', 1, false);


--
-- Name: popups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.popups_id_seq', 1, false);


--
-- Name: public_bank_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.public_bank_users_id_seq', 1, false);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.questions_id_seq', 1, false);


--
-- Name: reinforce_similar_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.reinforce_similar_cache_id_seq', 1, false);


--
-- Name: study_learning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.study_learning_id_seq', 1, false);


--
-- Name: study_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.study_review_id_seq', 1, false);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.subjects_id_seq', 1, false);


--
-- Name: system_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.system_config_id_seq', 1, false);


--
-- Name: user_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_answers_id_seq', 1, false);


--
-- Name: user_bank_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_bank_answers_id_seq', 1, false);


--
-- Name: user_bank_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_bank_categories_id_seq', 1, false);


--
-- Name: user_bank_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_bank_favorites_id_seq', 1, false);


--
-- Name: user_bank_mistakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_bank_mistakes_id_seq', 1, false);


--
-- Name: user_bank_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_bank_questions_id_seq', 1, false);


--
-- Name: user_checkins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_checkins_id_seq', 1, false);


--
-- Name: user_coding_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_coding_stats_id_seq', 1, false);


--
-- Name: user_follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_follows_id_seq', 1, false);


--
-- Name: user_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_progress_id_seq', 1, false);


--
-- Name: user_question_banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_question_banks_id_seq', 1, false);


--
-- Name: user_quiz_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_quiz_stats_id_seq', 1, false);


--
-- Name: user_remarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_remarks_id_seq', 1, false);


--
-- Name: user_subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.user_subjects_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: studyuser
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: bank_share_records bank_share_records_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records
    ADD CONSTRAINT bank_share_records_pkey PRIMARY KEY (id);


--
-- Name: bank_share_records bank_share_records_share_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records
    ADD CONSTRAINT bank_share_records_share_id_user_id_key UNIQUE (share_id, user_id);


--
-- Name: bank_shares bank_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares
    ADD CONSTRAINT bank_shares_pkey PRIMARY KEY (id);


--
-- Name: bank_shares bank_shares_share_code_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares
    ADD CONSTRAINT bank_shares_share_code_key UNIQUE (share_code);


--
-- Name: bank_shares bank_shares_share_token_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares
    ADD CONSTRAINT bank_shares_share_token_key UNIQUE (share_token);


--
-- Name: chat_conversations chat_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_pkey PRIMARY KEY (id);


--
-- Name: chat_members chat_members_conversation_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_conversation_id_user_id_key UNIQUE (conversation_id, user_id);


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: code_drafts code_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_drafts
    ADD CONSTRAINT code_drafts_pkey PRIMARY KEY (id);


--
-- Name: code_drafts code_drafts_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_drafts
    ADD CONSTRAINT code_drafts_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: code_submissions code_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_submissions
    ADD CONSTRAINT code_submissions_pkey PRIMARY KEY (id);


--
-- Name: coding_questions coding_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_questions
    ADD CONSTRAINT coding_questions_pkey PRIMARY KEY (id);


--
-- Name: coding_statistics coding_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_statistics
    ADD CONSTRAINT coding_statistics_pkey PRIMARY KEY (id);


--
-- Name: coding_statistics coding_statistics_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_statistics
    ADD CONSTRAINT coding_statistics_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: coding_subjects coding_subjects_name_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_subjects
    ADD CONSTRAINT coding_subjects_name_key UNIQUE (name);


--
-- Name: coding_subjects coding_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_subjects
    ADD CONSTRAINT coding_subjects_pkey PRIMARY KEY (id);


--
-- Name: duplicate_check_records duplicate_check_records_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.duplicate_check_records
    ADD CONSTRAINT duplicate_check_records_pkey PRIMARY KEY (id);


--
-- Name: email_verification_codes email_verification_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.email_verification_codes
    ADD CONSTRAINT email_verification_codes_pkey PRIMARY KEY (id);


--
-- Name: exam_questions exam_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_pkey PRIMARY KEY (id);


--
-- Name: exam_templates exam_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_templates
    ADD CONSTRAINT exam_templates_pkey PRIMARY KEY (id);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: forum_boards forum_boards_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_boards
    ADD CONSTRAINT forum_boards_pkey PRIMARY KEY (id);


--
-- Name: forum_boards forum_boards_slug_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_boards
    ADD CONSTRAINT forum_boards_slug_key UNIQUE (slug);


--
-- Name: forum_comments forum_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_pkey PRIMARY KEY (id);


--
-- Name: forum_favorites forum_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_favorites
    ADD CONSTRAINT forum_favorites_pkey PRIMARY KEY (id);


--
-- Name: forum_likes forum_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_likes
    ADD CONSTRAINT forum_likes_pkey PRIMARY KEY (id);


--
-- Name: forum_mentions forum_mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_mentions
    ADD CONSTRAINT forum_mentions_pkey PRIMARY KEY (id);


--
-- Name: forum_poll_votes forum_poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_poll_votes
    ADD CONSTRAINT forum_poll_votes_pkey PRIMARY KEY (id);


--
-- Name: forum_posts forum_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_pkey PRIMARY KEY (id);


--
-- Name: forum_reactions forum_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reactions
    ADD CONSTRAINT forum_reactions_pkey PRIMARY KEY (id);


--
-- Name: forum_reports forum_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reports
    ADD CONSTRAINT forum_reports_pkey PRIMARY KEY (id);


--
-- Name: forum_user_bans forum_user_bans_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_user_bans
    ADD CONSTRAINT forum_user_bans_pkey PRIMARY KEY (id);


--
-- Name: interaction_notifications interaction_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.interaction_notifications
    ADD CONSTRAINT interaction_notifications_pkey PRIMARY KEY (id);


--
-- Name: mistakes mistakes_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.mistakes
    ADD CONSTRAINT mistakes_pkey PRIMARY KEY (id);


--
-- Name: mistakes mistakes_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.mistakes
    ADD CONSTRAINT mistakes_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: notification_dismissals notification_dismissals_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_pkey PRIMARY KEY (id);


--
-- Name: notification_dismissals notification_dismissals_user_id_notification_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_user_id_notification_id_key UNIQUE (user_id, notification_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: popup_dismissals popup_dismissals_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_dismissals
    ADD CONSTRAINT popup_dismissals_pkey PRIMARY KEY (id);


--
-- Name: popup_dismissals popup_dismissals_user_id_popup_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_dismissals
    ADD CONSTRAINT popup_dismissals_user_id_popup_id_key UNIQUE (user_id, popup_id);


--
-- Name: popup_views popup_views_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_views
    ADD CONSTRAINT popup_views_pkey PRIMARY KEY (id);


--
-- Name: popups popups_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popups
    ADD CONSTRAINT popups_pkey PRIMARY KEY (id);


--
-- Name: public_bank_users public_bank_users_bank_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.public_bank_users
    ADD CONSTRAINT public_bank_users_bank_id_user_id_key UNIQUE (bank_id, user_id);


--
-- Name: public_bank_users public_bank_users_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.public_bank_users
    ADD CONSTRAINT public_bank_users_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: reinforce_similar_cache reinforce_similar_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.reinforce_similar_cache
    ADD CONSTRAINT reinforce_similar_cache_pkey PRIMARY KEY (id);


--
-- Name: reinforce_similar_cache reinforce_similar_cache_source_scope_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.reinforce_similar_cache
    ADD CONSTRAINT reinforce_similar_cache_source_scope_id_key UNIQUE (source, scope_id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: study_learning study_learning_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_learning
    ADD CONSTRAINT study_learning_pkey PRIMARY KEY (id);


--
-- Name: study_learning study_learning_user_id_source_scope_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_learning
    ADD CONSTRAINT study_learning_user_id_source_scope_id_question_id_key UNIQUE (user_id, source, scope_id, question_id);


--
-- Name: study_review study_review_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_review
    ADD CONSTRAINT study_review_pkey PRIMARY KEY (id);


--
-- Name: study_review study_review_user_id_source_scope_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_review
    ADD CONSTRAINT study_review_user_id_source_scope_id_question_id_key UNIQUE (user_id, source, scope_id, question_id);


--
-- Name: subjects subjects_name_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_name_key UNIQUE (name);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: system_config system_config_config_key_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_config_key_key UNIQUE (config_key);


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- Name: forum_favorites uq_forum_favorite; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_favorites
    ADD CONSTRAINT uq_forum_favorite UNIQUE (user_id, post_id);


--
-- Name: forum_likes uq_forum_like; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_likes
    ADD CONSTRAINT uq_forum_like UNIQUE (user_id, target_type, target_id);


--
-- Name: forum_poll_votes uq_forum_poll_vote; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_poll_votes
    ADD CONSTRAINT uq_forum_poll_vote UNIQUE (post_id, user_id, option_index);


--
-- Name: forum_reactions uq_forum_reaction; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reactions
    ADD CONSTRAINT uq_forum_reaction UNIQUE (user_id, target_type, target_id, emoji);


--
-- Name: interaction_notifications uq_interaction_notifications_dedup; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.interaction_notifications
    ADD CONSTRAINT uq_interaction_notifications_dedup UNIQUE (user_id, actor_id, action_type, target_type, target_id);


--
-- Name: user_follows uq_user_follows_pair; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT uq_user_follows_pair UNIQUE (follower_id, following_id);


--
-- Name: user_answers user_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_pkey PRIMARY KEY (id);


--
-- Name: user_bank_answers user_bank_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers
    ADD CONSTRAINT user_bank_answers_pkey PRIMARY KEY (id);


--
-- Name: user_bank_answers user_bank_answers_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers
    ADD CONSTRAINT user_bank_answers_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: user_bank_categories user_bank_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_categories
    ADD CONSTRAINT user_bank_categories_pkey PRIMARY KEY (id);


--
-- Name: user_bank_categories user_bank_categories_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_categories
    ADD CONSTRAINT user_bank_categories_user_id_name_key UNIQUE (user_id, name);


--
-- Name: user_bank_favorites user_bank_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites
    ADD CONSTRAINT user_bank_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_bank_favorites user_bank_favorites_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites
    ADD CONSTRAINT user_bank_favorites_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: user_bank_mistakes user_bank_mistakes_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes
    ADD CONSTRAINT user_bank_mistakes_pkey PRIMARY KEY (id);


--
-- Name: user_bank_mistakes user_bank_mistakes_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes
    ADD CONSTRAINT user_bank_mistakes_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: user_bank_questions user_bank_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_questions
    ADD CONSTRAINT user_bank_questions_pkey PRIMARY KEY (id);


--
-- Name: user_checkins user_checkins_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_checkins
    ADD CONSTRAINT user_checkins_pkey PRIMARY KEY (id);


--
-- Name: user_checkins user_checkins_user_id_checkin_date_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_checkins
    ADD CONSTRAINT user_checkins_user_id_checkin_date_key UNIQUE (user_id, checkin_date);


--
-- Name: user_coding_stats user_coding_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_coding_stats
    ADD CONSTRAINT user_coding_stats_pkey PRIMARY KEY (id);


--
-- Name: user_coding_stats user_coding_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_coding_stats
    ADD CONSTRAINT user_coding_stats_user_id_key UNIQUE (user_id);


--
-- Name: user_follows user_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_user_id_p_key_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_p_key_key UNIQUE (user_id, p_key);


--
-- Name: user_question_banks user_question_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_banks
    ADD CONSTRAINT user_question_banks_pkey PRIMARY KEY (id);


--
-- Name: user_question_tag_items user_question_tag_items_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_tag_items
    ADD CONSTRAINT user_question_tag_items_pkey PRIMARY KEY (user_id, scope, scope_id, question_id, tag);


--
-- Name: user_quiz_stats user_quiz_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_quiz_stats
    ADD CONSTRAINT user_quiz_stats_pkey PRIMARY KEY (id);


--
-- Name: user_quiz_stats user_quiz_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_quiz_stats
    ADD CONSTRAINT user_quiz_stats_user_id_key UNIQUE (user_id);


--
-- Name: user_remarks user_remarks_owner_user_id_target_user_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_remarks
    ADD CONSTRAINT user_remarks_owner_user_id_target_user_id_key UNIQUE (owner_user_id, target_user_id);


--
-- Name: user_remarks user_remarks_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_remarks
    ADD CONSTRAINT user_remarks_pkey PRIMARY KEY (id);


--
-- Name: user_subjects user_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects
    ADD CONSTRAINT user_subjects_pkey PRIMARY KEY (id);


--
-- Name: user_subjects user_subjects_user_id_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects
    ADD CONSTRAINT user_subjects_user_id_subject_id_key UNIQUE (user_id, subject_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: ix_chat_messages_conv_created; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_chat_messages_conv_created ON public.chat_messages USING btree (conversation_id, created_at);


--
-- Name: ix_code_submissions_user_question; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_code_submissions_user_question ON public.code_submissions USING btree (user_id, question_id);


--
-- Name: ix_email_codes_email_type_used; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_email_codes_email_type_used ON public.email_verification_codes USING btree (email, code_type, is_used);


--
-- Name: ix_exam_questions_exam_id; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_exam_questions_exam_id ON public.exam_questions USING btree (exam_id);


--
-- Name: ix_favorites_user_question; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_favorites_user_question ON public.favorites USING btree (user_id, question_id);


--
-- Name: ix_forum_boards_sort; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_boards_sort ON public.forum_boards USING btree (sort_order);


--
-- Name: ix_forum_boards_subject; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE UNIQUE INDEX ix_forum_boards_subject ON public.forum_boards USING btree (subject_id) WHERE (subject_id IS NOT NULL);


--
-- Name: ix_forum_comments_author; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_comments_author ON public.forum_comments USING btree (author_id);


--
-- Name: ix_forum_comments_parent; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_comments_parent ON public.forum_comments USING btree (parent_id);


--
-- Name: ix_forum_comments_post; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_comments_post ON public.forum_comments USING btree (post_id, is_deleted, created_at);


--
-- Name: ix_forum_comments_post_deleted; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_comments_post_deleted ON public.forum_comments USING btree (post_id, is_deleted);


--
-- Name: ix_forum_mentions_source; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_mentions_source ON public.forum_mentions USING btree (source_type, source_id);


--
-- Name: ix_forum_mentions_user; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_mentions_user ON public.forum_mentions USING btree (mentioned_user_id, is_read);


--
-- Name: ix_forum_poll_votes_post; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_poll_votes_post ON public.forum_poll_votes USING btree (post_id);


--
-- Name: ix_forum_posts_author; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_posts_author ON public.forum_posts USING btree (author_id, is_deleted);


--
-- Name: ix_forum_posts_board_created; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_posts_board_created ON public.forum_posts USING btree (board_id, is_deleted, created_at);


--
-- Name: ix_forum_posts_board_deleted_created; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_posts_board_deleted_created ON public.forum_posts USING btree (board_id, is_deleted, created_at);


--
-- Name: ix_forum_posts_pinned; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_posts_pinned ON public.forum_posts USING btree (board_id, is_pinned, last_comment_at);


--
-- Name: ix_forum_posts_search; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_posts_search ON public.forum_posts USING gin (search_vector);


--
-- Name: ix_forum_reactions_target; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_reactions_target ON public.forum_reactions USING btree (target_type, target_id);


--
-- Name: ix_forum_reports_status; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_reports_status ON public.forum_reports USING btree (status);


--
-- Name: ix_forum_reports_target; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_reports_target ON public.forum_reports USING btree (target_type, target_id);


--
-- Name: ix_forum_user_bans_user; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_forum_user_bans_user ON public.forum_user_bans USING btree (user_id, is_active);


--
-- Name: ix_interaction_notifications_user; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_interaction_notifications_user ON public.interaction_notifications USING btree (user_id, is_read);


--
-- Name: ix_mistakes_user_question; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_mistakes_user_question ON public.mistakes USING btree (user_id, question_id);


--
-- Name: ix_notifications_is_active; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_notifications_is_active ON public.notifications USING btree (is_active);


--
-- Name: ix_questions_subject_id; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_questions_subject_id ON public.questions USING btree (subject_id);


--
-- Name: ix_questions_subject_type; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_questions_subject_type ON public.questions USING btree (subject_id, type);


--
-- Name: ix_study_review_user_due; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_study_review_user_due ON public.study_review USING btree (user_id, next_due_at);


--
-- Name: ix_user_answers_user_created; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_answers_user_created ON public.user_answers USING btree (user_id, created_at);


--
-- Name: ix_user_answers_user_question; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_answers_user_question ON public.user_answers USING btree (user_id, question_id);


--
-- Name: ix_user_bank_answers_user_bank; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_bank_answers_user_bank ON public.user_bank_answers USING btree (user_id, bank_id);


--
-- Name: ix_user_bank_favorites_user_bank; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_bank_favorites_user_bank ON public.user_bank_favorites USING btree (user_id, bank_id);


--
-- Name: ix_user_bank_mistakes_user_bank; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_bank_mistakes_user_bank ON public.user_bank_mistakes USING btree (user_id, bank_id);


--
-- Name: ix_user_bank_questions_bank_id; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_bank_questions_bank_id ON public.user_bank_questions USING btree (bank_id);


--
-- Name: ix_user_follows_follower; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_follows_follower ON public.user_follows USING btree (follower_id);


--
-- Name: ix_user_follows_following; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_follows_following ON public.user_follows USING btree (following_id);


--
-- Name: ix_user_progress_user_id; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_progress_user_id ON public.user_progress USING btree (user_id);


--
-- Name: ix_user_subjects_user_id; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_user_subjects_user_id ON public.user_subjects USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_openid; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE INDEX ix_users_openid ON public.users USING btree (openid);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: studyuser
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: bank_share_records bank_share_records_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records
    ADD CONSTRAINT bank_share_records_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: bank_share_records bank_share_records_share_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records
    ADD CONSTRAINT bank_share_records_share_id_fkey FOREIGN KEY (share_id) REFERENCES public.bank_shares(id) ON DELETE CASCADE;


--
-- Name: bank_share_records bank_share_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_share_records
    ADD CONSTRAINT bank_share_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bank_shares bank_shares_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares
    ADD CONSTRAINT bank_shares_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: bank_shares bank_shares_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.bank_shares
    ADD CONSTRAINT bank_shares_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: code_drafts code_drafts_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_drafts
    ADD CONSTRAINT code_drafts_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.coding_questions(id) ON DELETE CASCADE;


--
-- Name: code_drafts code_drafts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_drafts
    ADD CONSTRAINT code_drafts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: code_submissions code_submissions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_submissions
    ADD CONSTRAINT code_submissions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.coding_questions(id) ON DELETE CASCADE;


--
-- Name: code_submissions code_submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.code_submissions
    ADD CONSTRAINT code_submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coding_questions coding_questions_coding_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_questions
    ADD CONSTRAINT coding_questions_coding_subject_id_fkey FOREIGN KEY (coding_subject_id) REFERENCES public.coding_subjects(id) ON DELETE CASCADE;


--
-- Name: coding_statistics coding_statistics_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_statistics
    ADD CONSTRAINT coding_statistics_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.coding_questions(id) ON DELETE CASCADE;


--
-- Name: coding_statistics coding_statistics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.coding_statistics
    ADD CONSTRAINT coding_statistics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: duplicate_check_records duplicate_check_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.duplicate_check_records
    ADD CONSTRAINT duplicate_check_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: duplicate_check_records duplicate_check_records_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.duplicate_check_records
    ADD CONSTRAINT duplicate_check_records_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: email_verification_codes email_verification_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.email_verification_codes
    ADD CONSTRAINT email_verification_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: exam_questions exam_questions_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id) ON DELETE CASCADE;


--
-- Name: exam_templates exam_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exam_templates
    ADD CONSTRAINT exam_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: exams exams_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: favorites favorites_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_boards forum_boards_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_boards
    ADD CONSTRAINT forum_boards_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_boards forum_boards_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_boards
    ADD CONSTRAINT forum_boards_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: forum_comments forum_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_comments forum_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.forum_comments(id) ON DELETE CASCADE;


--
-- Name: forum_comments forum_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_comments forum_comments_reply_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_reply_to_user_id_fkey FOREIGN KEY (reply_to_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_favorites forum_favorites_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_favorites
    ADD CONSTRAINT forum_favorites_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_favorites forum_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_favorites
    ADD CONSTRAINT forum_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_likes forum_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_likes
    ADD CONSTRAINT forum_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_mentions forum_mentions_mentioned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_mentions
    ADD CONSTRAINT forum_mentions_mentioned_user_id_fkey FOREIGN KEY (mentioned_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_mentions forum_mentions_mentioner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_mentions
    ADD CONSTRAINT forum_mentions_mentioner_id_fkey FOREIGN KEY (mentioner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_poll_votes forum_poll_votes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_poll_votes
    ADD CONSTRAINT forum_poll_votes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_poll_votes forum_poll_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_poll_votes
    ADD CONSTRAINT forum_poll_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.forum_boards(id) ON DELETE CASCADE;


--
-- Name: forum_reactions forum_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reactions
    ADD CONSTRAINT forum_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_reports forum_reports_handled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reports
    ADD CONSTRAINT forum_reports_handled_by_fkey FOREIGN KEY (handled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_reports forum_reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_reports
    ADD CONSTRAINT forum_reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_user_bans forum_user_bans_banned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_user_bans
    ADD CONSTRAINT forum_user_bans_banned_by_fkey FOREIGN KEY (banned_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_user_bans forum_user_bans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.forum_user_bans
    ADD CONSTRAINT forum_user_bans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: interaction_notifications interaction_notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.interaction_notifications
    ADD CONSTRAINT interaction_notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: interaction_notifications interaction_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.interaction_notifications
    ADD CONSTRAINT interaction_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mistakes mistakes_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.mistakes
    ADD CONSTRAINT mistakes_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: mistakes mistakes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.mistakes
    ADD CONSTRAINT mistakes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_dismissals notification_dismissals_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_dismissals notification_dismissals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: popup_dismissals popup_dismissals_popup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_dismissals
    ADD CONSTRAINT popup_dismissals_popup_id_fkey FOREIGN KEY (popup_id) REFERENCES public.popups(id) ON DELETE CASCADE;


--
-- Name: popup_dismissals popup_dismissals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_dismissals
    ADD CONSTRAINT popup_dismissals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: popup_views popup_views_popup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_views
    ADD CONSTRAINT popup_views_popup_id_fkey FOREIGN KEY (popup_id) REFERENCES public.popups(id) ON DELETE CASCADE;


--
-- Name: popup_views popup_views_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popup_views
    ADD CONSTRAINT popup_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: popups popups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.popups
    ADD CONSTRAINT popups_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: public_bank_users public_bank_users_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.public_bank_users
    ADD CONSTRAINT public_bank_users_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: public_bank_users public_bank_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.public_bank_users
    ADD CONSTRAINT public_bank_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: questions questions_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: study_learning study_learning_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_learning
    ADD CONSTRAINT study_learning_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: study_review study_review_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.study_review
    ADD CONSTRAINT study_review_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_answers user_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: user_answers user_answers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_bank_answers user_bank_answers_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers
    ADD CONSTRAINT user_bank_answers_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: user_bank_answers user_bank_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers
    ADD CONSTRAINT user_bank_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.user_bank_questions(id) ON DELETE CASCADE;


--
-- Name: user_bank_answers user_bank_answers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_answers
    ADD CONSTRAINT user_bank_answers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_bank_categories user_bank_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_categories
    ADD CONSTRAINT user_bank_categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_bank_favorites user_bank_favorites_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites
    ADD CONSTRAINT user_bank_favorites_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: user_bank_favorites user_bank_favorites_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites
    ADD CONSTRAINT user_bank_favorites_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.user_bank_questions(id) ON DELETE CASCADE;


--
-- Name: user_bank_favorites user_bank_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_favorites
    ADD CONSTRAINT user_bank_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_bank_mistakes user_bank_mistakes_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes
    ADD CONSTRAINT user_bank_mistakes_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: user_bank_mistakes user_bank_mistakes_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes
    ADD CONSTRAINT user_bank_mistakes_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.user_bank_questions(id) ON DELETE CASCADE;


--
-- Name: user_bank_mistakes user_bank_mistakes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_mistakes
    ADD CONSTRAINT user_bank_mistakes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_bank_questions user_bank_questions_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_questions
    ADD CONSTRAINT user_bank_questions_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.user_question_banks(id) ON DELETE CASCADE;


--
-- Name: user_bank_questions user_bank_questions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_bank_questions
    ADD CONSTRAINT user_bank_questions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_checkins user_checkins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_checkins
    ADD CONSTRAINT user_checkins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_coding_stats user_coding_stats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_coding_stats
    ADD CONSTRAINT user_coding_stats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_progress user_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_question_banks user_question_banks_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_banks
    ADD CONSTRAINT user_question_banks_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.user_bank_categories(id) ON DELETE SET NULL;


--
-- Name: user_question_banks user_question_banks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_banks
    ADD CONSTRAINT user_question_banks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_question_tag_items user_question_tag_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_question_tag_items
    ADD CONSTRAINT user_question_tag_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_quiz_stats user_quiz_stats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_quiz_stats
    ADD CONSTRAINT user_quiz_stats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_remarks user_remarks_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_remarks
    ADD CONSTRAINT user_remarks_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_remarks user_remarks_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_remarks
    ADD CONSTRAINT user_remarks_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subjects user_subjects_restricted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects
    ADD CONSTRAINT user_subjects_restricted_by_fkey FOREIGN KEY (restricted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_subjects user_subjects_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects
    ADD CONSTRAINT user_subjects_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: user_subjects user_subjects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studyuser
--

ALTER TABLE ONLY public.user_subjects
    ADD CONSTRAINT user_subjects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict z1WtMlR6yYQw03tpudwwpaKX8EgZyTnNheMcOu3b2U4ejrcOeQRS83Y3S1VHpuL

